package edu.txstate.jam723.restaurantcateringapp;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class RestaurantAdapter extends ArrayAdapter<Restaurants> {
    private Context context;
    private int resource;

    public RestaurantAdapter(@Nullable Context context, int resource, @NonNull List<Restaurants> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
    }
    private class ViewHolder{
        ImageView imageView;
        TextView textView;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Restaurants selectedRestaurants = getItem(position);
        LayoutInflater mInflater = (LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        ViewHolder holder = null;

        if (convertView == null) {
            holder = new ViewHolder ();
            convertView = mInflater.inflate(resource, null);
            holder.textView = convertView.findViewById(R.id.txtView);
            holder.imageView = convertView.findViewById(R.id.imgView);
            convertView.setTag(holder);
        }
        else{
            holder = (ViewHolder) convertView.getTag();
        }
        holder.textView.setText(selectedRestaurants.getName() + " " + selectedRestaurants.getCity());
        holder.imageView.setImageResource(selectedRestaurants.getImage());

        return convertView;

    }
}
