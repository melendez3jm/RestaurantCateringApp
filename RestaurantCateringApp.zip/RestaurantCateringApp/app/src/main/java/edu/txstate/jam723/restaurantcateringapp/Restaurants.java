package edu.txstate.jam723.restaurantcateringapp;

import androidx.annotation.NonNull;

public class Restaurants {
    private int id;
    private String name;
    private String city;
    private String url;
    private String phone;
    private double costPerPerson;
    private int image;

    @NonNull
    @Override
    public String toString() { return id + ": " + name + city; }

    public Restaurants(int id, String name, String city, String url, String phone, double costPerPerson, int image) {
        this.id = id;
        this.name = name;
        this.city = city;
        this.url = url;
        this.phone = phone;
        this.costPerPerson = costPerPerson;
        this.image = image;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public double getCostPerPerson() { return costPerPerson; }
    public void setCostPerPerson(double costPerPerson) { this.costPerPerson = costPerPerson; }
    public int getImage() { return image; }
    public void setImage(int image) { this.image = image; }
}
