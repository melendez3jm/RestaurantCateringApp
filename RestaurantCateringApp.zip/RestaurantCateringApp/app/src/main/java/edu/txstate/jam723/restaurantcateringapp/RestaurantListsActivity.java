package edu.txstate.jam723.restaurantcateringapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class RestaurantListsActivity extends ListActivity {

    List<Restaurants> restaurantsList = new ArrayList<Restaurants>();


    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        Restaurants selectedRestaurant = restaurantsList.get(position);

        DecimalFormat f = new DecimalFormat("###,###.##");
        Toast.makeText(RestaurantListsActivity.this, "Cost per person is: $" +
                f.format(selectedRestaurant.getCostPerPerson()), Toast.LENGTH_SHORT).show();

        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(RestaurantListsActivity.this);
        SharedPreferences.Editor editor = pref.edit();
        editor.putInt("KeyID", selectedRestaurant.getId());
        editor.putString("KeyName", selectedRestaurant.getName());
        editor.putString("KeyCity", selectedRestaurant.getCity());
        editor.putString("KeyURL", selectedRestaurant.getUrl());
        editor.putString("KeyPhone",  selectedRestaurant.getPhone());
        editor.putFloat("KeyCost", (float) selectedRestaurant.getCostPerPerson());
        editor.putInt("KeyImage", selectedRestaurant.getImage());

        editor.commit();

        startActivity(new Intent(RestaurantListsActivity.this, RestaurantDetailActivity.class));
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Restaurants restaurants1 = new Restaurants(101, "Chick-Fil-A", "San Marcos, Texas","https://www.chick-fil-a.com/orderfood", "512-392-5771", 12.00, R.drawable.chick);
        Restaurants restaurants2 = new Restaurants(102, "McAlisters","San Marcos, Texas","https://www.mcalistersdeli.com/catering", "512-212-4004", 15.00, R.drawable.mcalister);
        Restaurants restaurants3 = new Restaurants(103, "Dagar's Catering", "Austin, Texas","https://www.dagarscatering.com/catering-menus", "512-719-5524", 45.00, R.drawable.dagars);
        Restaurants restaurants4 = new Restaurants(104, "Vanilla Orchid Catering", "Austin, Texas","https://www.thevanillaorchid.com/food-catering/", "512-610-2134", 60.00, R.drawable.vanilla);
        Restaurants restaurants5 = new Restaurants(105, "Theadus Catering", "Houston, Texas","https://www.excellentevents.com/menu","713-863-0555", 40.00, R.drawable.theadus);

        restaurantsList.add(restaurants1);
        restaurantsList.add(restaurants2);
        restaurantsList.add(restaurants3);
        restaurantsList.add(restaurants4);
        restaurantsList.add(restaurants5);

        setListAdapter(new RestaurantAdapter(this, R.layout.restaurants_list, restaurantsList));



    }
}