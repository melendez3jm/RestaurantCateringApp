package edu.txstate.jam723.restaurantcateringapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class RestaurantDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant_detail);

        TextView RestaurantID = findViewById(R.id.txtID);
        TextView RestaurantName = findViewById(R.id.txtName);
        TextView RestaurantCity = findViewById(R.id.txtCity);
        TextView RestaurantPhone = findViewById(R.id.txtPhoneNumber);
        TextView RestaurantCostPerPerson = findViewById(R.id.txtCostPerPerson);
        final EditText numberOfPersons = findViewById(R.id.txtNumberOfPerson);


        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(RestaurantDetailActivity.this);

        final Restaurants selectedRestaurant = new Restaurants(pref.getInt("KeyID", 0),
                pref.getString("KeyName", null),
                pref.getString("KeyCity", null),
                pref.getString("KeyURL", null),
                pref.getString("KeyPhone", null),
                pref.getFloat("KeyCost", 0),
                pref.getInt("KeyImage", 0));

        DecimalFormat f = new DecimalFormat("###,###.##");


        RestaurantID.setText("ID: " + String.valueOf(selectedRestaurant.getId()));
        RestaurantName.setText("Name: " + selectedRestaurant.getName());
        RestaurantCity.setText("City: " + selectedRestaurant.getCity());
        RestaurantPhone.setText("Phone: " + selectedRestaurant.getPhone());
        RestaurantCostPerPerson.setText("$" + f.format(selectedRestaurant.getCostPerPerson()));

        Button calculate = findViewById(R.id.btnCalculate);

        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    int intNumPersons = Integer.parseInt(numberOfPersons.getText().toString());
                    double totalCost = selectedRestaurant.getCostPerPerson() * intNumPersons;
                    Toast.makeText(RestaurantDetailActivity.this, "Total Cost: $" + totalCost, Toast.LENGTH_LONG).show();
                }
                catch(Exception ex){
                    Toast.makeText(RestaurantDetailActivity.this, "Please enter a whole number for the number of Person's", Toast.LENGTH_LONG).show();
                }
            }
        });

        Button getInfo = findViewById(R.id.btnInfo);

        getInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedRestaurant.getUrl().equals(null)) {

                } else {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(selectedRestaurant.getUrl())));
                }
            }
        });
    }
}